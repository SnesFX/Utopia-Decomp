This model was part of the collection that Techokami asked to have submitted to the Models Resource. Some things about them have fixed up or changed slightly, but credit for these models still belongs to the original submitters.  

Originally Submitted by: divx2k60